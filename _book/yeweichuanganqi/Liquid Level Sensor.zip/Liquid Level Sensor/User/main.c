/*********************************************************************************************************
*
* File                : main.c
* Hardware Environment: 
* Build Environment   : RealView MDK-ARM  Version: 4.20
* Version             : V1.0
* By                  : 
*
*                                  (c) Copyright 2005-2011, WaveShare
*                                       http://www.waveshare.net
*                                          All Rights Reserved
*
*********************************************************************************************************/

/* Includes ------------------------------------------------------------------*/
#include "stm32f10x.h"
#include "systick.h"
#include <stdio.h>
#include "usart.h"

/* Private define ------------------------------------------------------------*/
#define ADC1_DR_Address    ((u32)0x4001244C)

/* Private function prototypes -----------------------------------------------*/
void USART_Configuration(void);
void ADC_Configuration(void);

/* Private variables ---------------------------------------------------------*/
float AD_value;
//ADCת���ĵ�ѹֵͨ��MDA��ʽ����SRAM
vu16 ADC_ConvertedValue;

/*******************************************************************************
* Function Name  : main
* Description    : Main program
* Input          : None
* Output         : None
* Return         : None
* Attention		 : None
*******************************************************************************/
int main(void)
{
	Delay_Init();
	usart_Configuration();
	ADC_Configuration();
  	printf("\r\n****************************************************************\r\n");
  	/* Infinite loop */
  	while (1)
  	{
    	/* Printf message with AD value to serial port every 1 second */
	  	AD_value = ADC_ConvertedValue;
	  	AD_value = (AD_value/4096)*3.3;
//  	if(AD_value>1.2)
//			printf("High water level!\r\n");
//		else
//			printf("Low water level!\r\n");
//	  	Delay(100);   /* delay 1000ms */   
			printf("%lf\r\n",AD_value);
	} 	
}

/*******************************************************************************
* Function Name  : ADC_Configuration
* Description    : Configure the ADC.
* Input          : None
* Output         : None
* Return         : None
* Attention		 : None
*******************************************************************************/
void ADC_Configuration(void)
{
  ADC_InitTypeDef ADC_InitStructure;
  DMA_InitTypeDef DMA_InitStructure;
  GPIO_InitTypeDef GPIO_InitStructure;

  RCC_AHBPeriphClockCmd(RCC_AHBPeriph_DMA1, ENABLE);
  RCC_APB2PeriphClockCmd(RCC_APB2Periph_ADC1 | RCC_APB2Periph_GPIOA | RCC_APB2Periph_AFIO, ENABLE);

  /* Configure PA.06 (ADC Channel6), PA.07 (ADC Channel7) as analog input -------------------------*/
  GPIO_InitStructure.GPIO_Pin = GPIO_Pin_6 | GPIO_Pin_7;
  GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AIN;
  GPIO_Init(GPIOA, &GPIO_InitStructure);   
   
  /* DMA channel1 configuration ----------------------------------------------*/
  DMA_DeInit(DMA1_Channel1);//ʹ��DMA1��ͨ��1
  DMA_InitStructure.DMA_PeripheralBaseAddr = ADC1_DR_Address;//ADC��ַ
  DMA_InitStructure.DMA_MemoryBaseAddr = (u32)&ADC_ConvertedValue;//�ڴ��ַ
  DMA_InitStructure.DMA_DIR = DMA_DIR_PeripheralSRC; //������
  DMA_InitStructure.DMA_BufferSize = 1; //����һ��halfword
  DMA_InitStructure.DMA_PeripheralInc = DMA_PeripheralInc_Disable;//�����ַ�̶�
  DMA_InitStructure.DMA_MemoryInc = DMA_MemoryInc_Disable;//�ڴ��ַ�̶�
  DMA_InitStructure.DMA_PeripheralDataSize = DMA_PeripheralDataSize_HalfWord;//����
  DMA_InitStructure.DMA_MemoryDataSize = DMA_MemoryDataSize_HalfWord; //ÿ�η���ʱ�����ݳ���
  DMA_InitStructure.DMA_Mode = DMA_Mode_Circular;//ѭ������
  DMA_InitStructure.DMA_Priority = DMA_Priority_High; //���ȼ�
  DMA_InitStructure.DMA_M2M = DMA_M2M_Disable; //2��memory�����������
  DMA_Init(DMA1_Channel1, &DMA_InitStructure);
  
  /* Enable DMA1 channel1 */
  DMA_Cmd(DMA1_Channel1, ENABLE); //ʹ������
    
  /* ADC1 configuration ------------------------------------------------------*/
  ADC_InitStructure.ADC_Mode = ADC_Mode_Independent;//����ADCģʽ
  ADC_InitStructure.ADC_ScanConvMode = ENABLE; //ɨ��ģʽ��ɨ��ģʽ���ڶ�ͨ���ɼ�
  ADC_InitStructure.ADC_ContinuousConvMode = ENABLE; //��������ת��ģʽ����ͣ�ؽ���ADCת��
  ADC_InitStructure.ADC_ExternalTrigConv = ADC_ExternalTrigConv_None;//��ʹ���ⲿ����ת��
  ADC_InitStructure.ADC_DataAlign = ADC_DataAlign_Right;//�ɼ������ҶԳ�
  ADC_InitStructure.ADC_NbrOfChannel = 1; //Ҫת����ͨ����Ŀ1
  ADC_Init(ADC1, &ADC_InitStructure); 

  /* ADC1 regular channel6 configuration */ 
	//ͨ��6Ϊ239��5���������ڣ�����Ϊ1
  ADC_RegularChannelConfig(ADC1, ADC_Channel_6, 1, ADC_SampleTime_239Cycles5);

  /* Enable ADC1 DMA */
  ADC_DMACmd(ADC1, ENABLE);
  
  /* Enable ADC1 */
  ADC_Cmd(ADC1, ENABLE);

  /* Enable ADC1 reset calibaration register  ��λУ׼�Ĵ���*/   
  ADC_ResetCalibration(ADC1);
  /* Check the end of ADC1 reset calibration register �ȴ�У׼�Ĵ�����λ���*/
  while(ADC_GetResetCalibrationStatus(ADC1));

  /* Start ADC1 calibaration ADCУ׼*/
  ADC_StartCalibration(ADC1);
  /* Check the end of ADC1 calibration �ȴ�У׼���*/
  while(ADC_GetCalibrationStatus(ADC1));
     
  /* Start ADC1 Software Conversion ����û���ⲿ������ʹ������ADCת��*/ 
  ADC_SoftwareStartConvCmd(ADC1, ENABLE);
}

#ifdef  USE_FULL_ASSERT

/**
  * @brief  Reports the name of the source file and the source line number
  *   where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t* file, uint32_t line)
{ 
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */

  /* Infinite loop */
  while (1)
  {
  }
}
#endif

/*********************************************************************************************************
      END FILE
*********************************************************************************************************/
